package com.dwaform.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DwaFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(DwaFormApplication.class, args);
	}

}
